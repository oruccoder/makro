<!doctype html>
<html>
<head>

    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <title>İşe Geç Gelme Tutanak Formu</title>

    <style>
        body {
            color: #2B2000;
        }

        .page {
            width: 210mm;
            height: 297mm;


        }


    </style>
</head>



<body style="font-family: Helvetica;">
<div class="page">
    <table>
        <tr>
            <td class="myco">
                <img src="<?php  $loc=location($this->aauth->get_user()->loc);  echo base_url('userfiles/company/' . $loc['logo']) ?>"
                     style="padding-left:18px;max-height:180px;max-width:250px;">
            </td>
            <td style="padding: 10px;width: 700px;">
                Makro 2000 Eğİtim Teknolojileri İnşaat Taahhüt  İç ve Dıs.<br>
                Ticaret Anonim“ Şirketinin  Azərbaycan Respublikasındakı Filialı<br>
                VÖEN: 1800732691 Baku / Azerbaycan<br>
                Phone : +994 12 597 48 18   Mail : info@makro2000.com.tr<br>
            </td>


        </tr>

    </table>
    <br>
    <h3 style="color: gray;text-align: center">İŞE GEÇ GELME TUTANAK FORMU</h3>
    <h3 style="text-align: center; text-decoration:underline">İHTARDIR</h3>
    <p style="text-align: right;">Tarih: ……. / …… /2020</p>

    <br>
    <p style="font-size: 12px; text-align: left;"><b>PERSONEL BİLGİLERİ</b></p>
    <table style="border: 2px solid #4a4a4a;font-size: 12px;width: 100%">
        <tr>
            <td style="border: 1px solid;width: 200px">ADI SOYADI :</td>
            <td style="border: 1px solid;"> &nbsp; </td>
        </tr>
        <tr>

            <td style="border: 1px solid;width: 200px">FİN NO:</td>
            <td style="border: 1px solid;"> &nbsp; </td>
        </tr>
        <tr>

            <td style="border: 1px solid;width: 200px">SÖZLEŞME NO:</td>
            <td style="border: 1px solid;"> &nbsp; </td>
        </tr>
        <tr>

            <td style="border: 1px solid;width: 200px">ÇALIŞTIĞI YER:</td>
            <td style="border: 1px solid;"> &nbsp; </td>
        </tr>
        <tr>

            <td style="border: 1px solid;width: 200px">ÇALIŞTIĞI BİRİM:</td>
            <td style="border: 1px solid;"> &nbsp; </td>
        </tr>
        <tr>

            <td style="border: 1px solid;width: 200px">İŞE GELMEDİĞİ TARİH:</td>
            <td style="border: 1px solid;"> &nbsp; </td>
        </tr>
        <tr>

            <td style="border: 1px solid;width: 200px">İŞBAŞI SAATİ:</td>
            <td style="border: 1px solid;"> &nbsp; </td>
        </tr>
    </table>

    <p style="font-size: 12px; text-align: left;"><b>İŞVERENİN</b></p>
    <p style="font-size: 12px;text-align: left;"><b>İŞYERİ ADI : Makro 2000 Eğitim Teknolojileri İnşaat Taahhüt  İç ve Dış Ticaret Anonim“ Şirketinin<br>&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Azərbaycan Respublikasındakı Filialı</b></p>
    <p style="font-size: 12px;text-align: left;"><b>ADRES : World Business Center Semed Vurgun 43, 3.Mertebe, Nesimi Rayonu Bakü Azerbaycan</b></p>
    <p style="font-size: 12px;text-align: left;"><b>TELEFON : + 994 12 597 48 18</b></p>

    <br>
    <p>Yukarıda adı, adresi belirtilen işyerimizin ……………………….  yerinde ………………………………….  biriminde çalışmakta olan ………………………….. sözleşme numaralı işçimiz belirtilen tarihte mazeretsiz ve bilgi vermeksizin mesaiye geç gelmiştir.</p>
    <p>Bu tutanak …… / …… / ………. tarihinde saat …… / ……  'da aşağıda isimleri yazılı tanıklar huzurunda düzenlenmiş,okunmuş ve imzalanmıştır.</p>

    <table style="text-align: center;width: 100%;">
        <tr>
            <td colspan="2">PROJE SORUMLUSU</td>
            <td colspan="2">Personel Müdürü</td>
            <td colspan="2">TANIK</td>
            <td colspan="2">TANIK</td>
        </tr>
    </table>


</div>

</body>
</html>
