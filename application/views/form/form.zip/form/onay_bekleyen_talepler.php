<div class="content-body">
    <div class="card">
        <div class="card-header">
            <a class="heading-elements-toggle"><i class="fa fa-ellipsis-v font-medium-3"></i></a>

            <div class="col-md-12">
                <form method="GET">
                <div class="btn-group box-shadow--8dp" role="group" style="background-color: white;margin: 8px 0px 6px 0px;border-radius: 3px !important;" >


                    <select class="form-control select2 select-box" id="tip" name="tip" style="width: 297px !important;">
                        <option value="0">Talep Tipi</option>
                        <option value="1">Malzeme Talep Formları</option>
                        <option value="4">Gider Talep Formları</option>
                        <option value="5">Avans Talep Formları</option>

                    </select>
                    &nbsp;   &nbsp;
                    <select class="form-control select2 select-box" id="proje_id" name="proje_id" style="width: 297px !important;">
                        <option value="0">Proje</option>
                        <?php
                        foreach (all_projects() as $agd) {?>
                            <option value="<?php echo $agd->id ?>"><?php echo $agd->name ?></option>

                        <?php } ?>

                    </select>
                    &nbsp;   &nbsp;
                    <select class="form-control select2 select-box" id="pers_id" name="pers_id" style="width: 297px !important;">
                        <option value="0">Personel</option>
                        <?php
                        foreach (personel_list() as $agd) {?>
                            <option value="<?php echo $agd['id'] ?>"><?php echo $agd['name'] ?></option>

                        <?php } ?>
                    </select>
                    &nbsp;   &nbsp;



                    <div class="col-md-2">
                        <input type="submit"  id="search" value="Filtrele" class="btn btn-info btn-md"/>

                    </div>
                    <div class="col-md-2">
                        <a href="/form/bekleyen_talepler" type="button"  value="Temizle" class="btn btn-success btn-md">Temizle</a>

                    </div>



                </div>
                </form>

            </div>
            <div class="heading-elements">
                <ul class="list-inline mb-0">
                    <li><a data-action="collapse"><i class="ft-minus"></i></a></li>
                    <li><a data-action="expand"><i class="ft-maximize"></i></a></li>
                    <li><a data-action="close"><i class="ft-x"></i></a></li>
                </ul>
            </div>
        </div>

        <div class="card-content">
            <div id="notify" class="alert alert-success" style="display:none;">
                <a href="#" class="close" data-dismiss="alert">&times;</a>

                <div class="message"></div>
            </div>

            <div class="card-body">
                <table id="productstable" class="table table-striped table-bordered zero-configuration" cellspacing="0"
                       width="100%">
                    <thead>
                    <tr>
                        <th>#</th>
                        <th><?php echo $this->lang->line('talep no') ?></th>
                        <th><?php echo $this->lang->line('proje name') ?></th>
                        <th><?php echo $this->lang->line('onay_kimde') ?></th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $i=1; foreach ($taleps as $tlp)
                    {

                        $onay_kontrol=talep_onay_iptal_kontrol($tlp->id);



                        if($onay_kontrol==0)
                        {
                            if($pers_id!=0)
                            {



                                    $personel=onay_kimde_ogren($tlp->tip,$tlp->id);

                                    $filter_name = personel_id_ogren($personel);

                                  


                                    if($filter_name==$pers_id)
                                    {
                                        if($tlp->tip==1) // Malzeme Talep
                                        {
                                            $href="/requested/view?id=".$tlp->id;

                                        }
                                        else if($tlp->tip==2) // Satın Alma Talep
                                        {
                                            $href="/form/satinalma_view?id=".$tlp->id;
                                        }
                                        else if($tlp->tip==4) // Gider Talep
                                        {
                                            $href="/form/gider_view?id=".$tlp->id;
                                        }

                                        else if($tlp->tip==5) // Avans Alma Talep
                                        {
                                            $href="/form/avans_view?id=".$tlp->id;
                                        }

                                            echo "<tr><td>$i</td>";
                                            echo "<td><a href='$href' class='btn btn-info'>$tlp->talep_no</a> </td>";
                                            echo "<td>$tlp->proje_name</td>";
                                            echo "<td>$personel</td></tr>";
                                            $i++;
                                    }




                            }
                            else
                                {
                                    $personel=onay_kimde_ogren($tlp->tip,$tlp->id);
                                    if($tlp->tip==1) // Malzeme Talep
                                    {
                                        $href="/requested/view?id=".$tlp->id;

                                    }
                                    else if($tlp->tip==2) // Satın Alma Talep
                                    {
                                        $href="/form/satinalma_view?id=".$tlp->id;
                                    }
                                    else if($tlp->tip==4) // Gider Talep
                                    {
                                        $href="/form/gider_view?id=".$tlp->id;
                                    }

                                    else if($tlp->tip==5) // Avans Alma Talep
                                    {
                                        $href="/form/avans_view?id=".$tlp->id;
                                    }

                                    echo "<tr><td>$i</td>";
                                    echo "<td><a href='$href' class='btn btn-info'>$tlp->talep_no</a> </td>";
                                    echo "<td>$tlp->proje_name</td>";
                                    echo "<td>$personel</td></tr>";
                                    $i++;
                                }

                        }


                    } ?>
                    </tbody>
                </table>
            </div>
            <input type="hidden" id="dashurl" value="products/prd_stats">
        </div>
    </div>
</div>