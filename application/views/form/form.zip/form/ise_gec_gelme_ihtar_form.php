<!doctype html>
<html>
<head>

    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <title>İşe Geç Gelme İhtar Formu</title>

    <style>
        body {
            color: #2B2000;
        }

        .page {
            width: 210mm;
            height: 297mm;


        }


    </style>
</head>



<body style="font-family: Helvetica;">
<div class="page">
    <table>
        <tr>
            <td class="myco">
                <img src="<?php  $loc=location($this->aauth->get_user()->loc);  echo base_url('userfiles/company/' . $loc['logo']) ?>"
                     style="padding-left:18px;max-height:180px;max-width:250px;">
            </td>
            <td style="padding: 10px;width: 700px;">
                Makro 2000 Eğİtim Teknolojileri İnşaat Taahhüt  İç ve Dıs.<br>
                Ticaret Anonim“ Şirketinin  Azərbaycan Respublikasındakı Filialı<br>
                VÖEN: 1800732691 Baku / Azerbaycan<br>
                Phone : +994 12 597 48 18   Mail : info@makro2000.com.tr<br>
            </td>


        </tr>

    </table>
    <br>
    <h3 style="color: gray;text-align: center">İŞE İZİNSİZ GEÇ GELME / GELMEME İHTARI</h3>
    <h3 style="text-align: center; text-decoration:underline">İHTARDIR</h3>
    <p style="text-align: right;padding-right: 100px">Tarih</p>

    <br>
    <h4 style="text-align: left; text-decoration:underline">İHTAR VEREN</h4>
    <p style="font-size: 10px; text-align: left;"><b>İŞVERENİN</b></p>
    <p style="font-size: 10px;text-align: left;"><b>İŞYERİ ADI : Makro 2000 Eğitim Teknolojileri İnşaat Taahhüt  İç ve Dış Ticaret Anonim“ Şirketinin<br>&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Azərbaycan Respublikasındakı Filialı</b></p>
    <p style="font-size: 10px;text-align: left;"><b>ADRES : World Business Center Semed Vurgun 43, 3.Mertebe, Nesimi Rayonu Bakü Azerbaycan</b></p>
    <p style="font-size: 10px;text-align: left;"><b>TELEFON : + 994 12 597 48 18</b></p>
    <br>
    <h4 style="text-align: left; text-decoration:underline">İHTAR ALAN</h4>
    <br>
    <p style="font-size: 10px; text-align: left;"><b>İŞÇİNİN</b></p>
    <p style="font-size: 10px; text-align: left;"><b>ADI SOYADI :</b></p>
    <p style="font-size: 10px; text-align: left;"><b>KİMLİK NO :</b></p>
    <p style="font-size: 10px; text-align: left;"><b>KİMLİK NO :</b></p>
    <p style="font-size: 10px; text-align: left;"><b>SÖZLEŞME NO :</b></p>
    <p style="font-size: 10px; text-align: left;"><b>ÇALIŞTIĞI YER :</b></p>
    <p style="font-size: 10px; text-align: left;"><b>ÇALIŞTIĞI BİRİM :</b></p>
    <br>
    <p>Sayın …………………………………………………………………………………………………..</p>
    <p>…… / …… / ……….. tarihinde iznimiz ve bilgimiz olmaksızın mesainize gelmediniz / geç geldiniz.</p>
    <p>Biginize rica olunur.</p>
    <p>*Tutanak ekte bilginize sunulmuştur.</p>

    <table style="text-align: center;width: 100%;">
        <tr>
            <td colspan="2">Personel Müdürü</td>
            <td colspan="2">Personel Onay</td>
            <td colspan="2">GENEL MÜDÜR <br>LOKMAN BİTER</td>
        </tr>
    </table>


</div>

</body>
</html>
